YUI.add("aui-datatable-core",function(e,t){e.DataTable.NAME="datatable",e.DataTable.CSS_PREFIX="table"},"2.0.0",{requires:["datatable-base","event-key","aui-event-base"],skinnable:!0});
