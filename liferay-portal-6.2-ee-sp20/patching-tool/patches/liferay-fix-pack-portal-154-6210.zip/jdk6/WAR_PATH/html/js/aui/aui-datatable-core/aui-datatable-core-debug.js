YUI.add('aui-datatable-core', function (A, NAME) {

A.DataTable.NAME = 'datatable';
A.DataTable.CSS_PREFIX = 'table';


}, '2.0.0', {"requires": ["datatable-base", "event-key", "aui-event-base"], "skinnable": true});
